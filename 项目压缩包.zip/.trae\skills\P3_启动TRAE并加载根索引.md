---
name: P3 锟斤拷锟斤拷TRAE锟斤拷锟斤拷锟截革拷锟斤拷锟斤拷
description: 执锟斤拷 P3 锟斤拷锟斤拷TRAE锟斤拷锟斤拷锟截革拷锟斤拷锟斤拷 锟斤拷锟借，锟斤拷锟斤拷锟侥匡拷锟斤拷锟斤拷械锟斤拷囟锟斤拷锟斤拷锟?allowed-tools: Bash, Read, Write
---
# P3_鍚姩TRAE骞跺姞杞芥牴绱㈠紩.md

## 鍓嶇疆鏉′欢
- `.ai/杩涘害鐘讹拷?json` 涓殑 `current_step` 蹇呴』锟?`P3`锟?- `P2.3` 宸插畬鎴愶拷?
## 鐩爣
纭褰撳墠鐜宸插惎锟?TRAE SOLO 妯″紡锛屽苟鍔犺浇鏍圭储寮曟枃锟?`docs/绱㈠紩.md`锛岀‘瀹氭暣涓祦绋嬬殑闃舵鍦板浘鍜屽姞杞借鍒欙拷?
## Action
- 妫€娴嬫槸鍚﹀湪 TRAE 鐜涓紙閫氳繃鐜鍙橀噺鎴栭厤缃枃浠讹級锟?- 濡傛灉鏈湪 TRAE 涓紝鎻愮ず鐢ㄦ埛"璇峰湪 TRAE 涓墦寮€椤圭洰骞跺垏鎹㈠埌 SOLO 妯″紡"锟?- 璇诲彇椤圭洰鏍圭洰褰曚笅锟?`docs/绱㈠紩.md` 鏂囦欢锛堝鏋滀笉瀛樺湪锛屽垯鎻愮ず鐢ㄦ埛杩愯鍚姩鍣ㄧ敓鎴愶級锟?- 瑙ｆ瀽绱㈠紩鏂囦欢锛岃幏鍙栭樁娈靛湴鍥俱€佸姞杞借鍒欍€佷汉宸ュ共棰勭偣鍒楄〃锟?- 灏嗙储寮曟憳瑕佸瓨锟?`.ai/绱㈠紩缂撳瓨.json`锟?
## Assert
- 褰撳墠鐜锟?TRAE SOLO 妯″紡锟?- `docs/绱㈠紩.md` 鏂囦欢瀛樺湪涓旀牸寮忔纭拷?
## Artefact
- `.ai/绱㈠紩缂撳瓨.json`

## Analysis
- 濡傛灉绱㈠紩鏂囦欢缂哄け锛屽垎鏋愬師鍥狅細鐢ㄦ埛鏈墽琛屽惎鍔ㄥ櫒鎴栭」鐩粨鏋勪笉瀹屾暣锟?- 妫€鏌ョ储寮曚腑鐨勯樁娈电紪鍙锋槸鍚︿笌鏍稿績濂戠害锟?3绔犱竴鑷达拷?
## Adjust
- 鑻ョ己灏戠储寮曟枃浠讹紝鎻愮ず鐢ㄦ埛鎵ц `A1_寮曞宸ヤ綔娴佺▼.md` 浠ョ敓鎴愭牳蹇冨绾﹀拰绱㈠紩锟?- 鑻ユā寮忎笉姝ｇ‘锛屾彁渚涘惎锟?TRAE SOLO 妯″紡鐨勬楠わ拷?
## Advance
- 鏇存柊 `.ai/杩涘害鐘讹拷?json`锟?  ```json
  {
    "current_step": "P4",
    "steps_completed": ["P1", "P2", "P2.1", "P2.2", "P2.3", "P3"]
  }
  ```
- 鎻愮ず鐢ㄦ埛锛氫笅涓€姝ュ簲鎵ц `P4`锟?
## 骞查
- 闇€瑕佺敤鎴风‘璁ゅ凡鍚姩 TRAE SOLO 妯″紡锛堣嫢鏃犳硶鑷姩妫€娴嬶級锟?


## When to Use This Skill
Use this skill when P3_启动TRAE并加载根索引 is required, such as during phase P tasks.

## Not For
- This skill does not handle other phases or unrelated tasks.
